#include "Cello.h"

int main(int argc, char** argv) {
  println("Cello World!");
  return 1;
}
